/*  Theme License
/* ------------------------------------ */

The theme itself is nothing but 100% GPLv3. See headers of files for further details.


/*  Font Awesome License
/* ------------------------------------ */

Font License - http://fontawesome.io
License: SIL OFL 1.1
License URI: http://scripts.sil.org/OFL
Copyright: Dave Gandy, http://fontawesome.io

Code License - http://fontawesome.io
License: MIT License
License URI: http://opensource.org/licenses/mit-license.html
Copyright: Dave Gandy, http://fontawesome.io

Brand Icons
All brand icons are trademarks of their respective owners.
The use of these trademarks does not indicate endorsement of the trademark holder by Font Awesome, nor vice versa.


/*  Titillium License
/* ------------------------------------ */

Titillium Font - http://www.campivisivi.net/titillium/
License: SIL OFL 1.1
License URI: http://scripts.sil.org/OFL
Copyright: Accademia di Belle Arti di Urbino, http://campivisivi.net


/*  Theme screenshot images
/* ------------------------------------ */

Left sidebar, top to bottom:

1. stockvault-stop-let-me-out102437 --- http://www.stockvault.net/photo/102437/
2. stockvault-sweet-delicious-fruit109569 --- http://www.stockvault.net/photo/109569/
3. sxc 863416_72821219 --- http://www.sxc.hu/browse.phtml?f=view&id=863416
4. stockvault-nature-friendship101987 - http://www.stockvault.net/photo/101987/
5. stockvault-rely-on102429 --- http://www.stockvault.net/photo/102429/
6. stockvault-city-skyline-at-sunset113039 --- http://www.stockvault.net/photo/113039/
7. stockvault-man-120087 --- http://www.stockvault.net/photo/120087/
8. sxc 959022_75540741 --- http://www.sxc.hu/browse.phtml?f=view&id=959022

Content, top to bottom, left to right:

1. Meditation a way of life, by Christopher Dippner --- http://spidermancrd.deviantart.com/art/Meditation-a-way-of-life-258464001
2. sxc 1116854_11833141 --- http://www.sxc.hu/browse.phtml?f=view&id=1116854
3. sxc 773565_26498242 --- http://www.sxc.hu/browse.phtml?f=view&id=773565
4. sxc 659668_35396697 --- http://www.sxc.hu/browse.phtml?f=view&id=659668
5. sxc 1289791_10648300 --- http://www.sxc.hu/browse.phtml?f=view&id=1289791

Right sidebar, top to bottom:

1. stockvault-malaysian-turtle101125 --- http://www.stockvault.net/photo/101125/
2. stockvault-rock118178 --- http://www.stockvault.net/photo/118178/
3. sxc 936076_54420437 --- http://www.sxc.hu/browse.phtml?f=view&id=936076
4. The theme author
5. sxc 78259_8811 --- http://www.sxc.hu/browse.phtml?f=view&id=78259
6. sxc 1064031_36665250 --- http://www.sxc.hu/browse.phtml?f=view&id=1064031


/*  Other Licenses
/* ------------------------------------ */

See headers of files for further details.
